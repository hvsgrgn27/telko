from socket import socket, AF_INET, SOCK_STREAM
from select import select
from time import sleep
import struct
import random

server_addr = ('localhost', 10000)

packer = struct.Struct("i")

op = ["BE", "KI"]

azon = str(random.randint(0,1000))
	
# server = socket(AF_INET,SOCK_STREAM)		# AF_INET - ipv4,  Sock_stream - TCP
with socket(AF_INET,SOCK_STREAM) as client:
	client.connect(server_addr)
	client.sendall(azon.encode())
	client.recv(20)
	while True:
		msg = op[random.randint(0,1)]
		num = str(random.randint(20000,100000))
		client.sendall((msg+"|"+num).encode())
		data = client.recv(packer.size)
		balance = packer.unpack(data)[0]
		print("Balance:",balance)
		sleep(2)