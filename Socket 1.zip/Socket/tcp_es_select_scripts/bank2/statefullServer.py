from socket import socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR
from select import select
import struct

server_addr = ('localhost', 10000)

packer = struct.Struct("i")

balance = {}
peerAzon = {}

with socket(AF_INET,SOCK_STREAM) as server:
	inputs = [server]
	server.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
	server.bind(server_addr)
	server.listen(1)
	
	while True:
		timeout = 1
		r, w, e = select(inputs,inputs,inputs,timeout)
		if not (r or w or e):
			continue
		
		for s in r:
			if s is server:
				client, client_addr = s.accept()
				inputs.append(client)

			else:
				data = s.recv(200)
				if not data:
					print("Kilepett",s)
					inputs.remove(s)
					s.close()
				else:
					allMsg = data.decode().strip("\x00").split("|")
					if (len(allMsg) == 1):
						azon = allMsg[0]
						if not azon in balance:
							balance[azon] = 0
						peerAzon[s.getpeername()] = azon
						client.sendall("OK".encode())
					else:
						msg, num = allMsg
						azon = peerAzon[s.getpeername()]
						print(azon,msg,num)
						num = int(num)
						plusminus = 1 if msg == "BE" else -1
						balance[azon] += plusminus * num
						
						resp = packer.pack(balance[azon])
						print(balance)

						s.sendall(resp)

			
			
			
			
			
			
			
