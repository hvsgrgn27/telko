import sys
import socket
import struct

server_addr = sys.argv[1]
server_port = int(sys.argv[2])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.bind((server_addr, server_port))

sock.listen(1)

int_packer = struct.Struct("i")
conn = None
while True:
    try:
        if not conn:
            conn, addr = sock.accept()
            print("Some has connected:", addr)
        string_length_packed = conn.recv(int_packer.size)  # packer.size
        if not string_length_packed:
            print("The client has terminated the connection")
            conn = None
            continue
        string_length = int_packer.unpack(string_length_packed)[0]
        packer = struct.Struct(f"{string_length}s i")
        msg = conn.recv(packer.size)
        text, times = packer.unpack(msg)
        text = text.decode("utf-8")
        print(f"The client's message: ({text},{times})")
        result = text*times
        result_encoded = result.encode()
        reply = int_packer.pack(len(result_encoded))
        reply += result_encoded
        conn.sendall(reply)
        print(f"Sent response: {len(result)}|{result}")
    except socket.timeout:
        pass
    except KeyboardInterrupt:
        print("Server shutting down")
        sock.close()
        break
