import sys
import socket
import random
import struct
import time
import string

server_addr = sys.argv[1]
server_port = int(sys.argv[2])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect((server_addr, server_port))

int_packer = struct.Struct("i")
for i in range(5):
    times = random.randint(2, 5)
    length = random.randint(1, 5)
    random_string = ''.join(random.choice(string.ascii_lowercase) for _ in range(length))
    random_string_encoded = random_string.encode("utf-8")
    packer = struct.Struct(f"{length}s i")
    msg = int_packer.pack(length) + packer.pack(random_string_encoded, times)
    print(f"Message: ({length})|({random_string},{times})")
    sock.sendall(msg)
    msg = sock.recv(int_packer.size)
    reply_length = int_packer.unpack(msg)[0]
    reply = sock.recv(reply_length).decode("utf-8")
    print(f"Reply: {reply}")

sock.close()
