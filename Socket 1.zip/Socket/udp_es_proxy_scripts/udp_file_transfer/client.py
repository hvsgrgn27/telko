import socket
import sys

BUFFER_SIZE = 200
END_BYTE = b"\x00"

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
    server_address = ("localhost", 10001)
    sock.settimeout(1.0)
    with open(sys.argv[1], "rb") as f:
        data = f.read(BUFFER_SIZE)
        while data:
            try:
                sock.sendto(data, server_address)
                print(f"Sent: {len(data)} bytes")
                reply, _ = sock.recvfrom(BUFFER_SIZE)
                print(f"Received: {reply.decode()}")
                data = f.read(BUFFER_SIZE)
            except socket.timeout:
                pass
    sock.sendto(END_BYTE, server_address)
