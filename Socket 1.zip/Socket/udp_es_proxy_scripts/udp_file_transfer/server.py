import socket
import sys

BUFFER_SIZE = 200

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    server_address = ("localhost", 10001)
    sock.bind(server_address)
    sock.settimeout(1.0)
    with open(sys.argv[1], "wb") as f:
        while True:
            try:
                data, client = sock.recvfrom(BUFFER_SIZE)
                if data == b"\x00":
                    end = True
                    print("Received null byte")
                    break
                print(f"Received {len(data)} bytes")
                f.write(data)
                sock.sendto("OK".encode(), client)
            except socket.timeout:
                pass
