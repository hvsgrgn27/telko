import sys
import socket
import select

proxy_addr = "localhost"
proxy_port = 10000
server_addr = "localhost"
server_port = 10001

BUFFER_SIZE = 200

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind((proxy_addr, proxy_port))

sock.listen(5)

proxy_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


inputs = [sock]

while True:
    try:
        readables, _, _ = select.select(inputs, [], [])

        for s in readables:
            if s is sock:
                connection, client_info = sock.accept()
                print(f"Someone has connected: {client_info[0]}:{client_info[1]}")
                inputs.append(connection)
            else:
                msg = s.recv(BUFFER_SIZE)
                if not msg:
                    s.close()
                    print("The client has terminated the connection")
                    inputs.remove(s)
                    continue
                parsed_msg = msg.decode()
                print(
                    f"The client's message: {parsed_msg}"
                )
                proxy_sock.sendto(msg, (server_addr, server_port))
                reply, _ = proxy_sock.recvfrom(BUFFER_SIZE)
                parsed_msg = reply.decode()
                print(
                    f"The server's response: {parsed_msg}"
                )
                s.sendall(reply)

    except KeyboardInterrupt:
        print("Proxy shutting down")
        proxy_sock.close()
        sock.close()
        break
