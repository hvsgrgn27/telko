import socket
import threading
import random
import turtle

# --- Beállítások ---
HOST = "0.0.0.0"
PORT = 9999
PLAYER_SPEED = 40
TARGET_RADIUS = 40

# --- Turtle setup ---
screen = turtle.Screen()
screen.title("UDP Turtle Game Server")
screen.setup(width=600, height=600)

# Cél objektum
target = turtle.Turtle()
target.shape("circle")
target.color("red")
target.penup()

# Játékosok tárolása
players = {}
next_id = 1

# UDP socket
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

def place_target():
	"""Új cél véletlen helyen, ahol nincs játékos."""
	while True:
		x = random.randint(-280, 280)
		y = random.randint(-280, 280)
		if all(abs(p.xcor() - x) > 30 and abs(p.ycor() - y) > 30 for p in players.values()):
			target.goto(x, y)
			break

place_target()

def move_player(pid, direction):
	"""Játékos mozgatása."""
	player = players[pid]
	x, y = player.xcor(), player.ycor()

	if direction == "fel":
		y += PLAYER_SPEED
		player.setheading(90)
	elif direction == "le":
		y -= PLAYER_SPEED
		player.setheading(270)
	elif direction == "balra":
		x -= PLAYER_SPEED
		player.setheading(180)
	elif direction == "jobbra":
		x += PLAYER_SPEED
		player.setheading(0)

	player.goto(x, y)

	# Ellenőrizzük, hogy elérte-e a célt
	if player.distance(target) < TARGET_RADIUS:
		place_target()
		return True
	return False

def handle_message(data, addr):
	global next_id

	msg = data.decode().strip()

	# Új játékos csatlakozik
	if msg == "csatlakozas":
		pid = str(next_id)
		next_id += 1

		t = turtle.Turtle()
		t.shape("turtle")
		t.penup()
		t.color(random.choice(["blue", "green", "purple", "orange", "black"]))
		t.goto(random.randint(-200, 200), random.randint(-200, 200))
		players[pid] = t

		server.sendto(f"azonosito:{pid}".encode(), addr)
		print(f"Új játékos {pid} csatlakozott {addr}-ról")
		return

	# Üzenet formátum: "pid:irány"
	try:
		pid, direction = msg.split(":")
		if pid in players:
			got_target = move_player(pid, direction)
			if got_target:
				server.sendto("Gratulálok!".encode(), addr)
			else:
				server.sendto("Nem talált!".encode(), addr)
	except Exception as e:
		print("Hibás üzenet:", msg, e)

def server_loop():
	print(f"Szerver fut: {HOST}:{PORT}")
	while True:
		data, addr = server.recvfrom(1024)
		handle_message(data, addr)

threading.Thread(target=server_loop, daemon=True).start()
turtle.done()
