from socket import *
import struct

server_addr = ("localhost", 10000) 

with socket(AF_INET, SOCK_DGRAM) as sock:
	sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)

	sock.bind((server_addr, server_port))
	sock.settimeout(1.0)

	packer = struct.Struct("i i 1s")
	packer_resp = struct.Struct("f")

	ops = {
		"+": lambda x, y: x + y,
		"-": lambda x, y: x - y,
		"*": lambda x, y: x * y,
		"/": lambda x, y: int(x / y),
	}

	while True:
		try:
			data, client = sock.recvfrom(packer.size)

			unpacked_data = packer.unpack(data)
			print("Received: ", unpacked_data)
			x = ops[unpacked_data[2].decode()](unpacked_data[0], unpacked_data[1])
			sock.sendto(packer_resp.pack(x), client)
			print(f"Sent:({x})")
		except timeout:
			pass
