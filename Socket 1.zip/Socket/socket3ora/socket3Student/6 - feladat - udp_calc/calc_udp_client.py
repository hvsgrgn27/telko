from socket import *
import random
import struct

server_addr = ("localhost", 10000)
ops = ["+", "-", "*", "/"]
packer = struct.Struct("i i c")
packer_resp = struct.Struct("f")

with socket(AF_INET, SOCK_DGRAM) as client:

	oper1 = random.randint(1, 100)
	oper2 = random.randint(1, 100)
	op = random.choice(ops)

	msg = packer.pack(oper1, oper2, op.encode())
	print(f"Message: {oper1} {op} {oper2}")
	client.sendto(msg, (server_addr, server_port))

	msg, _ = client.recvfrom(packer.size)
	parsed_msg = packer_resp.unpack(msg)
	print(f"Got result: {parsed_msg[0]}")
