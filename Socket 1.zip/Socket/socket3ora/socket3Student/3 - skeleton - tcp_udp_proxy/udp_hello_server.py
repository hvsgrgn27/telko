from socket import *

BUFFER_SIZE = 200

with socket(AF_INET, SOCK_DGRAM) as server:
	server.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)

	server_address = ('localhost', 10001)
	server.bind(server_address)
	server.settimeout(1.0)

	while True:
		try:
			data, client = server.recvfrom(BUFFER_SIZE)

			print('Received: ', data.decode())

			server.sendto("Hello client!".encode(), client)

		except timeout:
			pass
		except error as msg:
			print(msg)
