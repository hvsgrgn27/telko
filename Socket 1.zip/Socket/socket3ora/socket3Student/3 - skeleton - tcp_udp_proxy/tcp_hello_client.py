from socket import *

TCP_IP = "localhost"  # 127.0.0.1
TCP_PORT = 10000
BUFFER_SIZE = 200
MESSAGE = "Hello server".encode()  # could be just b"hello server"

with socket(AF_INET, SOCK_STREAM) as client:
	client.connect((TCP_IP, TCP_PORT))
	client.sendall(MESSAGE)
	print("Sent message:", MESSAGE)
	reply = client.recv(BUFFER_SIZE)

	print("Response:", reply.decode())
