from socket import *
import select

proxy_addr = ("localhost", 10000)
server_addr = ("localhost", 10001)

BUFFER_SIZE = 200

with socket(AF_INET, SOCK_STREAM) as proxy_server:
	proxy_server.bind(proxy_addr)
	proxy_server.listen(5)

	inputs = [proxy_server]

	while True:
		try:
			readables, _, _ = select.select(inputs, [], [], 1)

			for s in readables:
				if s is proxy_server:
					client, client_addr= proxy_server.accept()
					print(f"Someone has connected: {client_addr[0]}:{client_addr[1]}")
					inputs.append(client)
				else:
					msg = s.recv(BUFFER_SIZE)
					if not msg:
						s.close()
						print("The client has terminated the connection")
						inputs.remove(s)
					else:

		except KeyboardInterrupt:
			print("Proxy shutting down")
			break
