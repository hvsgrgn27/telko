import cv2
from threading import Thread, Lock
import time

def current_milli_time():
	return round(time.time() * 1000)

class VideoGrabber(Thread):
	"""A threaded video grabber.

	Attributes:
	encode_params ():
	cap (str):
	attr2 (:obj:`int`, optional): Description of `attr2`.

	"""
	def __init__(self, jpeg_quality):
		"""Constructor.

		Args:
		jpeg_quality (:obj:`int`): Quality of JPEG encoding, in 0, 100.

		"""
		Thread.__init__(self)
		self.encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality]
		self.init()
			
	def init(self):		
		# self.cap = cv2.VideoCapture(0)
		self.cap = cv2.VideoCapture("video.mp4")
		self.running = True
		self.buffer = None
		self.lock = Lock()
		self.quit = False
		self.lastTime = 0.0


	def stop(self):
		self.running = False
		self.quit = True
			
	def ret(self):
		self.lock.acquire()
		self.running = False
		self.lock.release()

	def get_buffer(self):
		"""Method to access the encoded buffer.

		Returns:
		np.ndarray: the compressed image if one has been acquired. None otherwise.
		"""
		# 25 fps
		if current_milli_time() - self.lastTime > 40:
			self.get_new_capture()
			self.lastTime = current_milli_time()
		if self.buffer is not None:
			self.lock.acquire()
			cpy = self.buffer.copy()
			self.lock.release()
			return cpy
			
	def get_new_capture(self):
		success, img = self.cap.read()
		if success:
			# JPEG compression
			# Protected by a lock
			# As the main thread may asks to access the buffer
			self.lock.acquire()
			result, self.buffer = cv2.imencode('.jpg', img, self.encode_param)
			self.lock.release()

	def run(self):
		while not self.quit:
			self.init()
			while self.running:
				time.sleep(5.0)
				'''				
				success, img = self.cap.read()
				if not success:
					continue

				# JPEG compression
				# Protected by a lock
				# As the main thread may asks to access the buffer
				self.lock.acquire()
				print("set buffer", img)
				result, self.buffer = cv2.imencode('.jpg', img, self.encode_param)
				self.lock.release()
				'''