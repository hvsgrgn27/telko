from socket import socket, AF_INET, SOCK_DGRAM, SOCK_STREAM
from struct import Struct

server_address = ('localhost',10000)
