from socket import *

server_address = ("localhost", 10000)

    