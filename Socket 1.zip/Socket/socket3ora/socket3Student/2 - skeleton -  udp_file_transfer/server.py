from socket import *
import sys

BUFFER_SIZE = 200
server_address = ("localhost", 10001)

with socket(AF_INET, SOCK_DGRAM) as sock, open(sys.argv[1], "wb") as f:
	sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
	sock.bind(server_address)
	sock.settimeout(1.0)
	
	while True:
		try:

		except timeout:
			pass
