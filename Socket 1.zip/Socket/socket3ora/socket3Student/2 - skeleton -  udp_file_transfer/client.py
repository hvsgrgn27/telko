from socket import *
import sys

BUFFER_SIZE = 200
END_BYTE = b"\x00"
server_address = ("localhost", 10001)

with socket(AF_INET, SOCK_DGRAM) as sock, open(sys.argv[1], "rb") as f:
	sock.settimeout(1.0)
	